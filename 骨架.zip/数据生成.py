import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

# 定义模型大小
model_size = (50, 50, 50)
background_label = 0
channel_label = 1

# 创建背景模型
model = np.full(model_size, background_label, dtype=np.int32)

# 定义S形河道中心线
x_center = np.linspace(1, 50, model_size[2])  # x方向的S形中心点
y_center = 15 + 10 * np.sin(np.linspace(0, 2 * np.pi, model_size[2]))  # y方向的S形

# 定义河道半径
channel_radius = 3

# 填充河道
def fill_channel(x_center, y_center, label):
    for z in range(model_size[2]):
        x_c = int(x_center[z])
        y_c = int(y_center[z])
        for x in range(model_size[0]):
            for y in range(model_size[1]):
                # 计算当前点到河道中心的距离
                distance = np.sqrt((x - x_c) ** 2 + (y - y_c) ** 2)
                if distance <= channel_radius:
                    model[x, y, z] = label

fill_channel(x_center, y_center, channel_label)

# 映射模型值
np.random.seed(33)  # 固定随机种子以保证结果可重复
background_range = (0, 30)
channel_range = (70, 100)

mapped_model = np.zeros_like(model, dtype=np.int32)
mapped_model[model == background_label] = np.random.randint(background_range[0], background_range[1] + 1, size=(model == background_label).sum())
mapped_model[model == channel_label] = np.random.randint(channel_range[0], channel_range[1] + 1, size=(model == channel_label).sum())

# 可视化切片（仅作为检查）
def visualize_slices(model):
    fig, axes = plt.subplots(1, 5, figsize=(20, 4))
    slices = [0, 10, 20, 30, 39]  # 显示几个关键切片
    for i, ax in enumerate(axes):
        ax.imshow(model[:, :, slices[i]], cmap='viridis')
        ax.set_title(f'Slice at Z={slices[i]}')
        ax.axis('off')
    plt.tight_layout()
    plt.show()

# 可视化河道3D形状
def visualize_3d(model):
    fig = plt.figure(figsize=(10, 10))
    ax = fig.add_subplot(111, projection='3d')
    
    # 获取河道点
    x, y, z = np.where((model >= channel_range[0]) & (model <= channel_range[1]))
    ax.scatter(x, y, z, c='blue', s=1, label='Channel')
    ax.set_xlim(0, model_size[0])
    ax.set_ylim(0, model_size[1])
    ax.set_zlim(0, model_size[2])
    ax.set_title("3D Visualization of S-Shaped Channel")
    ax.legend()
    plt.show()

# 显示结果
visualize_slices(mapped_model)
visualize_3d(mapped_model)

# 保存模型为文件（可选）
np.save("s.npy", mapped_model)
print("Model saved as 's.npy'")

# 保存模型为一列的txt文件
model_flattened = mapped_model.flatten()
np.savetxt("s.txt", model_flattened, fmt="%d")
print("Model saved as 's.txt'")



# import numpy as np
# import matplotlib.pyplot as plt
# from mpl_toolkits.mplot3d import Axes3D

# # 定义模型大小
# model_size = (50, 50, 50)

# # 创建随机模型
# np.random.seed(42)  # 固定随机种子以保证结果可重复
# random_model = np.random.randint(0, 101, size=model_size, dtype=np.int32)

# # 可视化切片（仅作为检查）
# def visualize_slices(model):
#     fig, axes = plt.subplots(1, 5, figsize=(20, 4))
#     slices = [0, 10, 20, 30, 49]  # 显示几个关键切片
#     for i, ax in enumerate(axes):
#         ax.imshow(model[:, :, slices[i]], cmap='viridis')
#         ax.set_title(f'Slice at Z={slices[i]}')
#         ax.axis('off')
#     plt.tight_layout()
#     plt.show()

# # 可视化随机模型3D形状
# def visualize_3d(model):
#     fig = plt.figure(figsize=(10, 10))
#     ax = fig.add_subplot(111, projection='3d')
    
#     # 获取模型点
#     x, y, z = np.where(model > 0)
#     ax.scatter(x, y, z, c=model[x, y, z], cmap='viridis', s=1)
#     ax.set_xlim(0, model_size[0])
#     ax.set_ylim(0, model_size[1])
#     ax.set_zlim(0, model_size[2])
#     ax.set_title("3D Visualization of Random Sandbody Model")
#     plt.show()

# # 显示结果
# visualize_slices(random_model)
# visualize_3d(random_model)

# # 保存模型为文件（可选）
# np.save("sandbody_model.npy", random_model)
# print("Model saved as 'sandbody_model.npy'")

# # 保存模型为一列的txt文件
# model_flattened = random_model.flatten()
# np.savetxt("sandbody_model.txt", model_flattened, fmt="%d")
# print("Model saved as 'sandbody_model.txt'")


import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

# 定义模型大小
model_size = (40, 40, 40)
background_label = 0
channel_label = 1

# 创建背景模型
model = np.full(model_size, background_label, dtype=np.int32)

# 定义单河道的中心线形状为S
# 使用z方向作为河道长度方向
x_center = np.linspace(10, 30, model_size[2])  # x方向的S形中心点
y_center = 15 + 5 * np.sin(np.linspace(0, 2 * np.pi, model_size[2]))  # y方向的S形

# 定义河道半径
channel_radius = 3

# 填充河道
for z in range(model_size[2]):
    x_c = int(x_center[z])
    y_c = int(y_center[z])
    for x in range(model_size[0]):
        for y in range(model_size[1]):
            # 计算当前点到河道中心的距离
            distance = np.sqrt((x - x_c) ** 2 + (y - y_c) ** 2)
            if distance <= channel_radius:
                model[x, y, z] = channel_label

# 映射模型值
np.random.seed(42)  # 固定随机种子以保证结果可重复
background_range = (0, 30)
channel_range = (70, 100)

mapped_model = np.zeros_like(model, dtype=np.int32)
mapped_model[model == background_label] = np.random.randint(background_range[0], background_range[1] + 1, size=(model == background_label).sum())
mapped_model[model == channel_label] = np.random.randint(channel_range[0], channel_range[1] + 1, size=(model == channel_label).sum())

# 可视化切片（仅作为检查）
def visualize_slices(model):
    fig, axes = plt.subplots(1, 5, figsize=(20, 4))
    slices = [0, 10, 20, 30, 39]  # 显示几个关键切片
    for i, ax in enumerate(axes):
        ax.imshow(model[:, :, slices[i]], cmap='viridis')
        ax.set_title(f'Slice at Z={slices[i]}')
        ax.axis('off')
    plt.tight_layout()
    plt.show()

# 可视化河道3D形状
def visualize_3d(model):
    fig = plt.figure(figsize=(10, 10))
    ax = fig.add_subplot(111, projection='3d')
    
    # 获取河道点
    x, y, z = np.where((model >= channel_range[0]) & (model <= channel_range[1]))
    ax.scatter(x, y, z, c='blue', s=1, label='Channel')
    ax.set_xlim(0, model_size[0])
    ax.set_ylim(0, model_size[1])
    ax.set_zlim(0, model_size[2])
    ax.set_title("3D Visualization of Single S-Shaped Channel")
    ax.legend()
    plt.show()

# 显示结果
visualize_slices(mapped_model)
visualize_3d(mapped_model)

# 保存模型为文件（可选）
np.save("single_channel_model_mapped.npy", mapped_model)
print("Model saved as 'single_channel_model_mapped.npy'")

# 保存模型为一列的txt文件
model_flattened = mapped_model.flatten()
np.savetxt("single_channel_model_mapped.txt", model_flattened, fmt="%d")
print("Model saved as 'single_channel_model_mapped.txt'")


